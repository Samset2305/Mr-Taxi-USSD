<?php

use AfricasTalking\SDK\AfricasTalking;
require 'vendor/autoload.php';

//Ensures this code runs only after a POST from AT

//remeber to return to if(!empty($_POST))
if(empty(!$_POST)) {

require_once('config.php'); // AT configuration file
require_once('dbConnector.php'); //Connects to database
require_once('AfricasTalking.php'); //AT Gateway
require_once('Service.php');
require_once('Payments.php'); //AT Payments
require_once('SMS.php'); //AT Sms

 
ini_set('error_log', 'ATussd-app-error.log');



// Reads the variables sent via POST from AT gateway


$sessionId   = $_POST["sessionId"];
$serviceCode = $_POST["serviceCode"];
$phoneNumber = $_POST["phoneNumber"];
$text        = $_POST["text"];  
 

 
// Initialize the SDK
$AT = new AfricasTalking($username, $apiKey);



//Explode the text to get the value of the latest interaction - think 1*1
$textArray = explode('*', $text);
$userResponse = trim(end($textArray));

//Set the default level of the user
$menuNumber = 0;

//Check the level of the user from the DB and retain default level if none is found for this session
$sql = "SELECT menuNumber FROM session_levels WHERE sessionId ='".$sessionId."' LIMIT 1";
$menuNumberQuery = $db->query($sql);
if ($menuNumberQueryResult = $menuNumberQuery->fetch_assoc()) {
    $menuNumber = $menuNumberQueryResult['menuNumber'];
}



if ($menuNumber == 0 || $menuNumber == 1) {

$phone_number = preg_replace("/^\+?234/", '0',$phoneNumber);

$data_string = array('phoneNumber' => $phone_number);
$data_string = json_encode($data_string);
$ch = curl_init('https://mrtaxiussd.herokuapp.com/check');                    
curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");                                                                     
curl_setopt($ch, CURLOPT_POSTFIELDS, $data_string);                                                                  
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);                                                                      
curl_setopt($ch, CURLOPT_HTTPHEADER, array(                                                                          
    'Content-Type: application/json'

    )); 
    
$result = curl_exec($ch);

$result = json_decode($result, true);





if($result['status']===TRUE){
    $sql9b = "INSERT INTO session_levels (sessionId,phoneNumber,menuNumber) VALUES('".$sessionId."','".$phoneNumber."', 12 )";
                    $db->query($sql9b);
							
							//Save table with details from Search
                    $sql9c = "INSERT INTO `ussdTransactions`( `phoneNumber`, `sessionId`) VALUES('".$phoneNumber."', '".$sessionId."')";
                    $db->query($sql9c);
                                             
                          
					$response= "CON Enter your origin address:";
				
                    
                    echo $response;
                   
                    
    
}else{
    
     $sql9b = "INSERT INTO session_levels (sessionId,phoneNumber,menuNumber) VALUES('".$sessionId."','".$phoneNumber."', 10 )";
                    $db->query($sql9b);
							
                     
					$sql9c = "INSERT INTO `ussdTransactions`( `phoneNumber`, `sessionId`) VALUES('".$phoneNumber."', '".$sessionId."')";
                    $db->query($sql9c);
                     
                                             
                          
					$response= "CON Enter your first name:";
                    
                    echo $response;
                   
                    
    
}

    }else {
        switch ($menuNumber) {
            
            
             case "10":
				     
				     $firstName= $userResponse;
                        
							//Save Location  address and Request Destionation Address
							
                            $sql = "UPDATE session_levels SET menuNUmber = 11 WHERE sessionId = '".$sessionId."'";
                            $db->query($sql);
							
							//Save Address
                            $sqla = "UPDATE ussdTransactions SET firstName='".$firstName."' WHERE sessionId = '".$sessionId."'";
							$db->query($sqla);
                                             
                          
					$response= "CON Enter your last name:";
                    
                    echo $response;
                    
                        break; 
            
            
            case "11":
				     
				     $lastName= $userResponse;
                        
							//Save Location  address and Request Destionation Address
							
                            $sql = "UPDATE session_levels SET menuNUmber = 12 WHERE sessionId = '".$sessionId."'";
                            $db->query($sql);
							
							//Save Address
                            $sqla = "UPDATE ussdTransactions SET lastName='".$lastName."' WHERE sessionId = '".$sessionId."'";
							$db->query($sqla);
                                             
                          
					$response= "CON Enter your origin address:";
                    
                    echo $response;
                    
                        break;
            
            
            
            
            
            
				 case "12":
				     
				     $originAddress= $userResponse;
                        
							//Save Location  address and Request Destionation Address
							
                            $sql = "UPDATE session_levels SET menuNUmber = 13 WHERE sessionId = '".$sessionId."'";
                            $db->query($sql);
							
							//Save Address
                            $sqla = "UPDATE ussdTransactions SET originAddress='".$originAddress."' WHERE sessionId = '".$sessionId."'";
							$db->query($sqla);
                                             
                          
					$response= "CON Enter your destination address:";
                    
                    echo $response;
                    
                        break;
						
					case "13":
                          $destinationAddress= $userResponse;
							//UPDATE Session 
                            $sql = "UPDATE session_levels SET menuNUmber = 14 WHERE sessionId = '".$sessionId."'";
                            $db->query($sql);
							
							//Save Address
                            $sqla = "UPDATE ussdTransactions SET destinationAddress='".$destinationAddress."' WHERE sessionId = '".$sessionId."'";
							$db->query($sqla);
                                             
 
$sqlwe = "SELECT * FROM ussdTransactions WHERE sessionId ='".$sessionId."' LIMIT 1";
$detailsQuery = $db->query($sqlwe);
$detailsQueryResult = $detailsQuery->fetch_assoc(); 

$firstName =$detailsQueryResult['firstName'];
$lastName  =$detailsQueryResult['lastName'];
$phoneNumber  =$detailsQueryResult['phoneNumber'];
$originAddress  =$detailsQueryResult['originAddress'];
$destinationAddress  =$detailsQueryResult['destinationAddress'];

$phone_number = preg_replace("/^\+?234/", '0',$phoneNumber);

$data_string = array(
    'firstName' => $firstName,
    'lastName' => $lastName,
    'phoneNumber' => $phone_number,
    'originAddress' => $originAddress,
    'destinationAddress' => $destinationAddress);
$data_string = json_encode($data_string);
$ch = curl_init('https://mrtaxiussd.herokuapp.com/createTrip');                    
curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");                                                                     
curl_setopt($ch, CURLOPT_POSTFIELDS, $data_string);                                                                  
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);                                                                      
curl_setopt($ch, CURLOPT_HTTPHEADER, array(                                                                          
    'Content-Type: application/json'

    )); 
    
$result = curl_exec($ch);

$result = json_decode($result, true);


echo "END Dear customer, your driver will contact you shortly.";


/*
if($result['message']===""){
    
    echo "END Dear customer, your driver will contact you shortly.";
    
    print_r($result);
    
}else{
    echo "END Dear Customer".$result['message'];
     print_r($result);
}

*/

   break;
					
		
           
           
} 



}
}
?>