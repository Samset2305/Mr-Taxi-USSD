<?php


//This is the config.php file

// Specify your login credentials
$username   = "smarttickets";
$apiKey = "6497de772aa9799d81a30464e122ff6b8d953509648d3dae853d3cad2306773c";

